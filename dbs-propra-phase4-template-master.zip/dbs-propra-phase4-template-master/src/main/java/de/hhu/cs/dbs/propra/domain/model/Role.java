package de.hhu.cs.dbs.propra.domain.model;

public enum Role {
    USER, EMPLOYEE, ADMIN;
}
